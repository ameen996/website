<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Khana Khazana</title>

    <!-- Bootstrap core CSS -->
    <?php include("resource.php");?>
  </head>

  <body>
<div  class="container">
<br><br><br><br><br><br>
<center>
<h2 style="color:#ef5310;">KHANNA KHAZANA</h2></center>
<center>
<h3 style="color:#3135dd;">Contact Us</h3>
</center><br>
<center>
<p style="color:#000000;"><strong> Email</strong><a href="http://khanakhazana@gmail.com">
 khanakhazana@gmail.com </a>
</p>
</center>
<br> 
<center>
<h5 style="color:#0080c0;">
Via Mobile: 9833317452
</h5>
</center>





	


</div>
    <!-- Navigation -->
    <?php include("nav.php");?>

    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <div class="col-lg-3">
         
    </div>
    <!-- /.container -->

    <!-- Footer -->
    <?php include("footer.php");?>

    <!-- Bootstrap core JavaScript -->
    <script src="js/jquery.min.js"></script>

  </body>

</html>
