<!-- Footer -->

<footer class="py-2 bg-dark fixed-bottom"style="padding-top:100px;">
<div class="container">
<p class="m-0 text-center text-white">Copyright &copy; Khana Khazana 2017</p>
</div>
<!-- /.container -->
</footer>