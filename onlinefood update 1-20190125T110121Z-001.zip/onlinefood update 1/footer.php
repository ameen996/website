<footer class="py-2 bg-dark fixed-bottom" style="padding-top:200px;">
  <div class="container">
	<p class="m-0 text-center text-white">Copyright &copy; KHANNA KHAZANA 2018</p>
  </div>
  <!-- /.container -->
</footer>