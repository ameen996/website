<h2 class="my-4" style="color:#3366FF;"></h2>
<?php
/*
include("admin/conn.php");
$sql2="select * from category_details";
$result2=$conn->query($sql2);
if($result2->num_rows>0)
{
	while($row2=$result2->fetch_assoc())
	{
		echo '<a href="allitems.php?category_code='.$row2["category_code"].'" class="list-group-item">'.$row2["category_name"].'</a>';
	}
}*/
echo '<img src="cakeimg/images (1).jpg"  width="200" height="800" border="0" alt="">';
echo '<br><br>';
echo '<img src="cakeimg/recipe-for-mini-taco-stuffed-peppers.jpg" width="200" height="800" border="0" alt="">';

?>